# Daily Planner

Daily Planner is a tiny, beginner-friendly web app for organizing to-dos and quick notes. It runs entirely in your browser—no installs, no servers, and no build tools required.

## Features

- Manage daily tasks with due dates, completion tracking, filters, and search
- Quick notes with titles, rich text via line breaks, and instant editing
- Light/dark theme toggle stored per device
- Toast reminders for important actions (add, delete, switch theme)
- Works offline and keeps data in `localStorage`
- Accessible keyboard flow with focus styles, labels, and aria-live updates

## Getting Started

1. Download or clone this repository.
2. Open `index.html` in your browser (double-click is fine).
3. Start adding tasks and notes—your data is saved automatically on this device.

## File Structure

```
daily-planner/
├─ index.html      # App layout and markup
├─ styles.css      # Light/dark theme styling
├─ app.js          # Planner logic and localStorage helpers
├─ README.md       # Project information
└─ assets/
   └─ icon.png     # Placeholder app icon
```

## Export & Import

This starter keeps things simple—copy the contents of `localStorage` keys `dp_tasks_v1` and `dp_notes_v1` to back up data. To restore on another device, paste the JSON back into the same keys using your browser’s developer tools.

## Customizing Colors

All colors come from CSS custom properties. Update the light/dark palettes near the top of `styles.css` (`[data-theme='light']` and `[data-theme='dark']`) to tweak the scheme. The `data-theme` attribute on `<html>` is what the theme toggle updates.

## LocalStorage Keys

- Tasks: `dp_tasks_v1`
- Notes: `dp_notes_v1`
- Theme preference: `dp_theme`

Change these in `app.js` if you need a fresh set without clearing existing data. Search for `STORAGE_KEYS` to update them in one place.

