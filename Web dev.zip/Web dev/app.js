/**
 * Daily Planner
 * Vanilla JS task & note manager with localStorage persistence.
 */

const STORAGE_KEYS = {
  tasks: 'dp_tasks_v1',
  notes: 'dp_notes_v1',
  theme: 'dp_theme',
};

const state = {
  tasks: [],
  notes: [],
};

let currentTaskFilter = 'all';
let taskSearchTerm = '';
let noteSearchTerm = '';
let toastTimer = null;

const els = {
  root: document.documentElement,
  tabs: document.querySelectorAll('.tab-button'),
  panels: document.querySelectorAll('.panel'),
  taskForm: document.getElementById('taskForm'),
  taskTitle: document.getElementById('taskTitle'),
  taskDue: document.getElementById('taskDue'),
  taskList: document.getElementById('taskList'),
  taskCounter: document.getElementById('taskCounter'),
  taskFilterButtons: document.querySelectorAll('.filter-button'),
  clearCompleted: document.getElementById('clearCompleted'),
  taskSearch: document.getElementById('taskSearch'),
  noteForm: document.getElementById('noteForm'),
  noteTitle: document.getElementById('noteTitle'),
  noteContent: document.getElementById('noteContent'),
  noteList: document.getElementById('noteList'),
  noteSearch: document.getElementById('noteSearch'),
  toast: document.getElementById('toast'),
  themeToggle: document.getElementById('themeToggle'),
};

init();

/**
 * Initializes the application by loading persisted data,
 * binding events, and rendering the first view.
 */
function init() {
  const { tasks, notes } = loadState();
  state.tasks = tasks;
  state.notes = notes;

  initThemeToggle();
  bindEvents();

  renderTasks(currentTaskFilter, taskSearchTerm);
  renderNotes(noteSearchTerm);
}

/**
 * Loads tasks and notes stored in localStorage.
 * Seeds starter data if no previous state exists.
 * @returns {{tasks: Array, notes: Array}}
 */
function loadState() {
  try {
    const storedTasks = JSON.parse(localStorage.getItem(STORAGE_KEYS.tasks) || 'null');
    const storedNotes = JSON.parse(localStorage.getItem(STORAGE_KEYS.notes) || 'null');

    if (storedTasks && storedNotes) {
      return { tasks: storedTasks, notes: storedNotes };
    }

    const seededTasks = [
      {
        id: uid(),
        title: 'Review today’s schedule',
        due: new Date().toISOString().slice(0, 10),
        completed: false,
        createdAt: Date.now(),
      },
      {
        id: uid(),
        title: 'Plan meals for the week',
        completed: false,
        createdAt: Date.now(),
      },
    ];

    const seededNotes = [
      {
        id: uid(),
        title: 'Groceries',
        content: 'Eggs\nSpinach\nGranola',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
      {
        id: uid(),
        title: 'Ideas',
        content: 'Try a morning walk\nCall Sam about the trip',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
    ];

    saveState(seededTasks, seededNotes);
    return { tasks: seededTasks, notes: seededNotes };
  } catch (error) {
    console.error('Failed to load stored data', error);
    return { tasks: [], notes: [] };
  }
}

/**
 * Saves tasks and notes arrays into localStorage.
 * @param {Array} tasks - Task list to persist.
 * @param {Array} notes - Note list to persist.
 */
function saveState(tasks, notes) {
  localStorage.setItem(STORAGE_KEYS.tasks, JSON.stringify(tasks));
  localStorage.setItem(STORAGE_KEYS.notes, JSON.stringify(notes));
}

function bindEvents() {
  els.tabs.forEach((tab) =>
    tab.addEventListener('click', () => {
      switchPanel(tab.dataset.target);
    })
  );

  els.taskForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const title = els.taskTitle.value.trim();
    const due = els.taskDue.value;

    if (!title) {
      els.taskTitle.focus();
      return;
    }

    addTask(title, due || undefined);
    els.taskForm.reset();
    els.taskTitle.focus();
    showToast('Task added');
  });

  els.taskFilterButtons.forEach((button) =>
    button.addEventListener('click', () => {
      els.taskFilterButtons.forEach((b) => b.classList.remove('active'));
      button.classList.add('active');
      currentTaskFilter = button.dataset.filter;
      renderTasks(currentTaskFilter, taskSearchTerm);
    })
  );

  els.clearCompleted.addEventListener('click', () => {
    clearCompleted();
  });

  els.taskSearch.addEventListener('input', () => {
    taskSearchTerm = els.taskSearch.value.trim().toLowerCase();
    renderTasks(currentTaskFilter, taskSearchTerm);
  });

  els.noteForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const title = els.noteTitle.value.trim() || 'Untitled note';
    const content = els.noteContent.value.trim();

    if (!content && !els.noteTitle.value.trim()) {
      els.noteContent.focus();
      return;
    }

    addNote(title, content);
    els.noteForm.reset();
    els.noteTitle.focus();
    showToast('Note saved');
  });

  els.noteSearch.addEventListener('input', () => {
    noteSearchTerm = els.noteSearch.value.trim().toLowerCase();
    renderNotes(noteSearchTerm);
  });
}

/**
 * Adds a new task to state and updates the UI.
 * @param {string} title - Task title.
 * @param {string} [due] - Optional ISO date string.
 */
function addTask(title, due) {
  const newTask = {
    id: uid(),
    title,
    due,
    completed: false,
    createdAt: Date.now(),
  };

  state.tasks = [newTask, ...state.tasks];
  saveState(state.tasks, state.notes);
  renderTasks(currentTaskFilter, taskSearchTerm);
}

/**
 * Toggles the completion status of a task.
 * @param {string} id - Task identifier.
 */
function toggleTask(id) {
  state.tasks = state.tasks.map((task) =>
    task.id === id ? { ...task, completed: !task.completed } : task
  );
  saveState(state.tasks, state.notes);
  renderTasks(currentTaskFilter, taskSearchTerm);
}

/**
 * Updates an existing task with new fields.
 * @param {string} id - Task identifier.
 * @param {{title?: string, due?: string}} fields - Fields to update.
 */
function editTask(id, fields) {
  state.tasks = state.tasks.map((task) =>
    task.id === id ? { ...task, ...fields } : task
  );
  saveState(state.tasks, state.notes);
  renderTasks(currentTaskFilter, taskSearchTerm);
}

/**
 * Removes a task from state.
 * @param {string} id - Task identifier.
 */
function deleteTask(id) {
  state.tasks = state.tasks.filter((task) => task.id !== id);
  saveState(state.tasks, state.notes);
  renderTasks(currentTaskFilter, taskSearchTerm);
}

/**
 * Clears completed tasks from state.
 */
function clearCompleted() {
  const remaining = state.tasks.filter((task) => !task.completed);
  const removedCount = state.tasks.length - remaining.length;
  if (!removedCount) {
    showToast('No completed tasks to clear');
    return;
  }
  state.tasks = remaining;
  saveState(state.tasks, state.notes);
  renderTasks(currentTaskFilter, taskSearchTerm);
  showToast('Completed tasks cleared');
}

/**
 * Adds a new note to state.
 * @param {string} title - Note title.
 * @param {string} content - Body text.
 */
function addNote(title, content) {
  const newNote = {
    id: uid(),
    title,
    content,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  state.notes = [newNote, ...state.notes];
  saveState(state.tasks, state.notes);
  renderNotes(noteSearchTerm);
}

/**
 * Updates an existing note.
 * @param {string} id - Note identifier.
 * @param {{title?: string, content?: string}} fields - Fields to update.
 */
function editNote(id, fields) {
  state.notes = state.notes.map((note) =>
    note.id === id ? { ...note, ...fields, updatedAt: Date.now() } : note
  );
  saveState(state.tasks, state.notes);
  renderNotes(noteSearchTerm);
}

/**
 * Deletes a note from state.
 * @param {string} id - Note identifier.
 */
function deleteNote(id) {
  state.notes = state.notes.filter((note) => note.id !== id);
  saveState(state.tasks, state.notes);
  renderNotes(noteSearchTerm);
}

/**
 * Renders the task list according to filters and search term.
 * @param {'all'|'active'|'completed'} filter - Task filter selection.
 * @param {string} search - Lowercase search query.
 */
function renderTasks(filter, search) {
  els.taskList.innerHTML = '';

  let filteredTasks = [...state.tasks];

  if (filter === 'active') {
    filteredTasks = filteredTasks.filter((task) => !task.completed);
  } else if (filter === 'completed') {
    filteredTasks = filteredTasks.filter((task) => task.completed);
  }

  if (search) {
    filteredTasks = filteredTasks.filter((task) =>
      task.title.toLowerCase().includes(search)
    );
  }

  filteredTasks.forEach((task) => {
    const item = document.createElement('li');
    item.className = `task-item${task.completed ? ' completed' : ''}`;
    item.dataset.id = task.id;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', `Mark ${task.title} as complete`);
    checkbox.addEventListener('change', () => toggleTask(task.id));

    const info = document.createElement('div');
    info.className = 'task-info';

    const title = document.createElement('p');
    title.className = 'task-title';
    title.textContent = task.title;
    info.appendChild(title);

    if (task.due) {
      const due = document.createElement('span');
      due.className = 'task-due';
      due.textContent = formatDate(task.due);
      info.appendChild(due);
    }

    const actions = document.createElement('div');
    actions.className = 'task-actions';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'icon-button';
    editBtn.textContent = '✏️';
    editBtn.setAttribute('aria-label', `Edit ${task.title}`);
    editBtn.addEventListener('click', () => openTaskEditor(task));

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'icon-button danger';
    deleteBtn.textContent = '🗑️';
    deleteBtn.setAttribute('aria-label', `Delete ${task.title}`);
    deleteBtn.addEventListener('click', () => {
      if (confirm('Delete this task?')) {
        deleteTask(task.id);
        showToast('Task deleted');
      }
    });

    actions.append(editBtn, deleteBtn);
    item.append(checkbox, info, actions);
    els.taskList.appendChild(item);
  });

  const activeCount = state.tasks.filter((task) => !task.completed).length;
  const totalCount = state.tasks.length;
  const countText =
    totalCount === 0
      ? 'No tasks yet'
      : `${activeCount} active / ${totalCount} total`;
  els.taskCounter.textContent = countText;
}

/**
 * Renders the note list filtered by search term.
 * @param {string} search - Lowercase search query.
 */
function renderNotes(search) {
  els.noteList.innerHTML = '';

  let filteredNotes = [...state.notes];
  if (search) {
    filteredNotes = filteredNotes.filter((note) => {
      const text = `${note.title} ${note.content}`.toLowerCase();
      return text.includes(search);
    });
  }

  filteredNotes.forEach((note) => {
    const card = document.createElement('article');
    card.className = 'note-card';
    card.dataset.id = note.id;

    const title = document.createElement('h3');
    title.className = 'note-title';
    title.textContent = note.title;

    const content = document.createElement('p');
    content.className = 'note-content';
    content.textContent = note.content || 'No content yet.';

    const meta = document.createElement('p');
    meta.className = 'note-meta';
    meta.textContent = `Updated ${formatDate(new Date(note.updatedAt).toISOString())}`;

    const actions = document.createElement('div');
    actions.className = 'note-actions';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'icon-button';
    editBtn.textContent = '✏️';
    editBtn.setAttribute('aria-label', `Edit note ${note.title}`);
    editBtn.addEventListener('click', () => openNoteEditor(note));

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'icon-button danger';
    deleteBtn.textContent = '🗑️';
    deleteBtn.setAttribute('aria-label', `Delete note ${note.title}`);
    deleteBtn.addEventListener('click', () => {
      if (confirm('Delete this note?')) {
        deleteNote(note.id);
        showToast('Note deleted');
      }
    });

    actions.append(editBtn, deleteBtn);
    card.append(title, content, meta, actions);
    els.noteList.appendChild(card);
  });
}

/**
 * Formats ISO date strings into a friendly label.
 * @param {string} isoString - ISO date string (YYYY-MM-DD).
 * @returns {string} Friendly date label.
 */
function formatDate(isoString) {
  if (!isoString) return '';

  const target = new Date(isoString);
  if (Number.isNaN(target.getTime())) {
    return 'Invalid date';
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const compare = new Date(target);
  compare.setHours(0, 0, 0, 0);

  const diffMs = compare.getTime() - today.getTime();
  const diffDays = Math.round(diffMs / 86400000);

  if (diffDays === 0) return 'Due today';
  if (diffDays === 1) return 'Due tomorrow';
  if (diffDays === -1) return 'Was due yesterday';
  if (diffDays > 1 && diffDays <= 7) return `Due in ${diffDays} days`;
  if (diffDays < -1 && diffDays >= -7) return `${Math.abs(diffDays)} days overdue`;

  return target.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: today.getFullYear() === target.getFullYear() ? undefined : 'numeric',
  });
}

/**
 * Generates a short unique identifier string.
 * @returns {string} Unique identifier.
 */
function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * Applies persisted theme preference and sets up toggle button.
 */
function applyTheme() {
  const storedTheme = localStorage.getItem(STORAGE_KEYS.theme) || 'light';
  els.root.setAttribute('data-theme', storedTheme);
  els.themeToggle.querySelector('.theme-icon').textContent =
    storedTheme === 'dark' ? '🌙' : '☀️';
}

/**
 * Initializes the theme toggle button behavior.
 */
function initThemeToggle() {
  applyTheme();
  els.themeToggle.addEventListener('click', () => {
    const next = els.root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    els.root.setAttribute('data-theme', next);
    localStorage.setItem(STORAGE_KEYS.theme, next);
    els.themeToggle.querySelector('.theme-icon').textContent =
      next === 'dark' ? '🌙' : '☀️';
    showToast(`Switched to ${next} theme`);
  });
}

function switchPanel(target) {
  els.tabs.forEach((tab) => {
    const isSelected = tab.dataset.target === target;
    tab.setAttribute('aria-selected', String(isSelected));
  });

  els.panels.forEach((panel) => {
    const show = (panel.id === 'todosPanel' && target === 'tasks') || (panel.id === 'notesPanel' && target === 'notes');
    panel.classList.toggle('hidden', !show);
    panel.toggleAttribute('hidden', !show);
  });

  if (target === 'tasks') {
    els.taskTitle.focus();
  } else {
    els.noteTitle.focus();
  }
}

function openTaskEditor(task) {
  const newTitle = prompt('Update task title:', task.title);
  if (newTitle === null) return;
  const trimmed = newTitle.trim();
  if (!trimmed) {
    showToast('Title cannot be empty');
    return;
  }

  const newDue = prompt(
    'Update due date (YYYY-MM-DD). Leave empty to remove:',
    task.due || ''
  );

  editTask(task.id, { title: trimmed, due: newDue ? newDue : undefined });
  showToast('Task updated');
}

function openNoteEditor(note) {
  const newTitle = prompt('Update note title:', note.title);
  if (newTitle === null) return;
  const newContent = prompt('Update note content:', note.content);
  if (newContent === null) return;

  editNote(note.id, {
    title: newTitle.trim() || 'Untitled note',
    content: newContent.trim(),
  });
  showToast('Note updated');
}

function showToast(message) {
  if (!els.toast) return;
  els.toast.textContent = message;
  els.toast.classList.add('show');

  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    els.toast.classList.remove('show');
  }, 2400);
}

